import streamlit as st
from langchain.docstore.document import Document
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains.summarize import load_summarize_chain
from langchain.chains.mapreduce import MapReduceChain
from langchain import HuggingFacePipeline
from langchain.llms import HuggingFaceHub
from langchain.prompts import PromptTemplate
from langchain import LLMChain
import textwrap
from transformers import pipeline
import langchain
langchain.verbose = False

# if nothing is specified for model_name we use ----
# model_name = "google/pegasus-xsum"
# model_tokenizer_ = AutoTokenizer.from_pretrained(model_name)

huggingfacehub_api_token="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"


# model_tokenizer_ = AutoTokenizer.from_pretrained(repo_id)


def generate_response_falcon(txt):
    repo_id = "tiiuae/falcon-7b-instruct"
    falcon_llm = HuggingFaceHub(huggingfacehub_api_token=huggingfacehub_api_token,
                     repo_id=repo_id, task='text-generation',
                    model_kwargs={"truncation":True, "temperature":0.5,"min_length":200,"max_length":300, "repetition_penalty":10.0})
    print(txt)
    sum_template = """write a summary of the following. Remember to include all the important information:'{text}'
    Answer: """
    print("\n\n",sum_template)
    
    sum_prompt = PromptTemplate(template=sum_template, input_variables=["text"])
    
    sum_llm_chain = LLMChain(prompt=sum_prompt, llm=falcon_llm)    
    summary = str(sum_llm_chain.run(txt))
    wrapped_text = textwrap.fill(summary, width=100, break_long_words=False, replace_whitespace=False)
    print(wrapped_text)
    return str(wrapped_text)

def generate_response_pegasus_xsum(txt):
    repo_id = "google/pegasus-xsum"
    model = pipeline("summarization", model=repo_id)
    summary = model(txt, truncation=True, max_length=250, min_length=30, do_sample=True)
    print(summary[0]['summary_text'])
    return summary[0]['summary_text']


def generate_response_bart_large(txt):
    repo_id = "facebook/bart-large-cnn"
    model = pipeline("summarization", model=repo_id)
    summary = model(txt, truncation=True, max_length=250, min_length=30, do_sample=True)
    print(summary[0]['summary_text'])
    return summary[0]['summary_text']


def generate_response_pegasus_cnn(txt):
    repo_id = "google/pegasus-cnn_dailymail"
    model = pipeline("summarization", model=repo_id)
    summary = model(txt, truncation=True, max_length=250, min_length=30, do_sample=True)
    print(summary)
    return summary


def generate_response_financial_summarization(txt):
    repo_id = "human-centered-summarization/financial-summarization-pegasus"
    model = pipeline("summarization", model=repo_id)
    summary = model(txt, truncation=True, max_length=250, min_length=30, do_sample=True)
    print(summary)
    return summary



# Page title

st.set_page_config(page_title='🔗 Text Summarization ')
image = "./logo.png"
st.image(image, caption=None, width=None, use_column_width=None, clamp=False, channels="RGB", output_format="auto")
st.title('🔗 Generative AI Powered Text Summarization ')
# Text input
txt_input = st.text_area('Enter your text', '', height=200)
# Form to accept user's text input for summarization
result = []
with st.form('summarize_form', clear_on_submit=True):
    options = st.selectbox(
    'Choose a model for summarization:',
    options=[ "google/pegasus-xsum", "facebook/bart-large-cnn", "google/pegasus-cnn_dailymail",
             "human-centered-summarization/financial-summarization-pegasus"])
    st.write('You selected:', options)
    submitted = st.form_submit_button('Submit')
    response = ''
    if submitted:
        if options=="human-centered-summarization/financial-summarization-pegasus":
            with st.spinner('Calculating...'):
                response = response + generate_response_financial_summarization(txt_input) 
        elif options=="google/pegasus-xsum":
            with st.spinner('Calculating...'):
                response = response + generate_response_pegasus_xsum(txt_input)
        elif options=="facebook/bart-large-cnn":
            with st.spinner('Calculating...'):
                response = response + generate_response_bart_large(txt_input)
        elif options=="google/pegasus-cnn_dailymail":
            with st.spinner('Calculating...'):
                response = response + generate_response_pegasus_cnn(txt_input)
        else:
            with st.spinner('Calculating...'):
                response = response + generate_response_falcon(txt_input)
            
st.info(response)


